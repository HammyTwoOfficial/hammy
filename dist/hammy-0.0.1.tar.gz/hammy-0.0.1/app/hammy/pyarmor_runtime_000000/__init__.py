# Pyarmor 8.5.9 (trial), 000000, 2024-06-02T18:24:06.040595
from .pyarmor_runtime import __pyarmor__
